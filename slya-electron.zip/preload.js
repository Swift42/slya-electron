const { contextBridge, ipcRenderer } = require('electron')

contextBridge.exposeInMainWorld('electronAPI', {
    openDevTools: () => ipcRenderer.send('openDevTools', ''),
    openUpdate: () => ipcRenderer.send('openUpdate', ''),
    updateToLatestSwift: () => ipcRenderer.send('updateToLatestSwift', ''),
})

ipcRenderer.on('firstinitdone', (event, data) => {
	const waitmsg = document.getElementById('wait');
	waitmsg.innerHTML='Latest version loaded - restarting ...';
});

ipcRenderer.on('update', (event, data) => {
  const oldOverlay = document.getElementById('updateOverlay');
  if(oldOverlay) oldOverlay.remove();
  
  const body = document.querySelector('body');
  let el = document.createElement('div')
  el.id = 'updateOverlay';
  el.style.backgroundColor = 'rgba(0,0,0,0.5)';
  el.style.top = 0;
  el.style.left = 0;
  el.style.width = '100vw';
  el.style.height = '100vh';
  el.style.position = 'absolute';
  el.style.zIndex = '1000';
  el.innerHTML = data
  body.append(el)
})
