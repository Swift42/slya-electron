const { ipcMain, session, app, BrowserWindow } = require('electron')
const path = require('node:path')
app.setPath('userData',path.join(__dirname, 'data'))

const createWindow = (version) => {
  const win = new BrowserWindow({
    width: 800,
    height: 600,
    icon: path.join(__dirname, 'app/icons/128.png'),
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js')
    }    
  })
  //win.webContents.openDevTools()  
  win.loadFile('app/index.html', { query: { version: version } } )
  return win
}

var version

async function updateSLYA()
{
	const response = await fetch ('https://raw.githubusercontent.com/Swift42/SLY-Assistant/refs/heads/patch-collection-for-0.7.0/SLY_Assistant.user.js')
	const file = await response.text();
	pos = file.indexOf('@version');
	pos2 = file.indexOf("\n",pos);
	version = file.substring(pos+8,pos2).trim();
	fs.writeFileSync("app/SLY_Assistant.user.js",file)
}	

function wait(ms) {	return new Promise(resolve => {	setTimeout(resolve, ms); }); }


app.whenReady().then(async () => {
const filter = {
  urls: ['https://rpc.ironforge.network/*']
}
session.defaultSession.webRequest.onBeforeSendHeaders(filter, (details, callback) => {
  details.requestHeaders['Origin'] = 'https://based.staratlas.com'
  callback({ requestHeaders: details.requestHeaders })
})

var win

fs = require("fs");
var firstinit=false;
if(!fs.existsSync("app/SLY_Assistant.user.js"))
{
	win = createWindow(version)
	await wait(500);
	updateSLYA();
	await wait(3000);
	win.webContents.send('firstinitdone','');
	await wait(3000);
	firstinit=true;
}
file = fs.readFileSync("app/SLY_Assistant.user.js").toString();
pos = file.indexOf('@version');
pos2 = file.indexOf("\n",pos);
version = file.substring(pos+8,pos2).trim();

if(firstinit)
{
	win.loadFile('app/index.html', { query: { version: version } } )
}
else
{
	win = createWindow(version)
}

  ipcMain.on('openDevTools', function() { win.openDevTools() })
  ipcMain.on('openUpdate', async function() {

	const response = await fetch ('https://raw.githubusercontent.com/Swift42/SLY-Assistant/refs/heads/patch-collection-for-0.7.0/SLY_Assistant.user.js')
	const file = await response.text();
	pos = file.indexOf('@version');
	pos2 = file.indexOf("\n",pos);
	var newVersion = file.substring(pos+8,pos2).trim();
	  
	win.webContents.send('update', '<div style="position:absolute;left:50%;margin-left:-200px;top:30vh;width:400px;text-align:center;background-color:white;padding:10px;color:black">UPDATE<br>Current version: '+version+'<br><button onClick="window.electronAPI.updateToLatestSwift()">Update to Swift\'s latest: '+newVersion+'</button><br><small>(The app will automatically restart after the update)</small><br><button onClick="document.getElementById(\'updateOverlay\').remove()">Cancel</button><br></div>');
  })
  ipcMain.on('updateToLatestSwift', async function() {
	updateSLYA();
	win.webContents.send('update', '<div style="position:absolute;left:50%;margin-left:-200px;top:40vh;width:400px;text-align:center;background-color:#eee;color:black">CODE UPDATED<br>Restarting ...<br></div>');
	setTimeout(function() { win.loadFile('app/index.html', { query: { version: version } } ) } , 2000 )
  })
  
  
})
